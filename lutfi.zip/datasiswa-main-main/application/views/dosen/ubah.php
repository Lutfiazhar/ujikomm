<div class="container">
    <form action="" method="post">
        <legend>Ubah Data Dosen</legend>
        <div class="mb-3">
            <input type="hidden" name="id" value="<?= $dosen['id']; ?>">
            <label for="dosen" class="form-label">Nama Dosen</label>
            <input type="text" class="form-control" id="dosen" name="dosen" value="<?= $dosen['dosen']; ?>" style="width : 300px;">
            <div class="form-text text-danger"><?= form_error('dosen'); ?></div>
        </div>
        <div class="mb-3">
            <input type="hidden" name="id" value="<?= $dosen['id']; ?>">
            <label for="mata_kuliah" class="form-label">Mata Kuliah</label>
            <input type="text" class="form-control" id="mata_kuliah" name="mata_kuliah" value="<?= $dosen['mata_kuliah']; ?>" style="width : 300px;">
            <div class="form-text text-danger"><?= form_error('mata_kuliah'); ?></div>
        </div>
        <input type="submit" name="ubah" value="ubah" class="btn btn-primary"></input>
    </form>
</div>