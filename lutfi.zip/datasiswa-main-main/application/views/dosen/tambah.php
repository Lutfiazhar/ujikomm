<div class="container">
    <form action="" method="post">
        <legend>Tambah Data Dosen</legend>
        <div class="mb-3">
            <label for="dosen" class="form-label">Nama Dosen</label>
            <input type="text" class="form-control" id="dosen" name="dosen" style="width : 300px;">
            <div class="form-text text-danger"><?= form_error('dosen'); ?></div>
        </div>
        <div class="mb-3">
            <label for="mata_kuliah" class="form-label">Mata Kuliah</label>
            <input type="text" class="form-control" id="mata_kuliah" name="mata_kuliah" style="width : 300px;">
            <div class="form-text text-danger"><?= form_error('mata_kuliah'); ?></div>
        </div>
        <input type="submit" value="submit" class="btn btn-primary"></input>
    </form>
</div>