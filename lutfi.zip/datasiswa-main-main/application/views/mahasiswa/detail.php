<div class="container">
    <div class="card" style="width: 18rem;">
    <img src="<?= base_url('assets/foto/') . $mahasiswa['foto']; ?>" class="card-img-top" alt="...">
        <div class="card-body">
            <h5 class="card-title"><?= $mahasiswa['nis']; ?></h5>
            <p class="card-text"><?= $mahasiswa['nama']; ?></p>
        </div>
        <ul class="list-group list-group-flush">
            <li class="list-group-item"><?= $mahasiswa['angkatan']; ?></li>
            <li class="list-group-item"><?= $mahasiswa['jurusan']; ?></li>
            <li class="list-group-item"><?= $mahasiswa['email']; ?></li>
            <li class="list-group-item"><?= $mahasiswa['hp']; ?></li>
            <li class="list-group-item"><?= $mahasiswa['alamat']; ?></li>
        </ul>
        <div class="card-body">
            <a href="<?= base_url('siswa'); ?>" class="btn btn-primary">Kembali</a>
        </div>
    </div>
</div>

